This is a project to check bayesian network's properties
